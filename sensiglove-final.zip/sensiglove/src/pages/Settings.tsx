import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Lock, Unlock } from "lucide-react";
import { Lang, t } from "@/lib/translations";
import {
  hasPin,
  setPin,
  verifyPin,
  getLockoutRemainingMs,
  getSettings,
  saveSettings,
  getProfiles,
  resetAll,
  type GloveSettings,
} from "@/lib/gloveStorage";
import { Slider } from "@/components/ui/slider";

const Settings = () => {
  const lang = (localStorage.getItem("sg-lang") as Lang) || "de";
  const T = (k: string) => t(k, lang);

  const [unlocked, setUnlocked] = useState(false);
  const [needsSetup, setNeedsSetup] = useState(!hasPin());

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b-2 border-border bg-card">
        <div className="container max-w-3xl py-4 flex items-center justify-between gap-4">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-sm font-medium text-foreground hover:text-primary focus-visible:outline-3 focus-visible:outline-offset-2 rounded-md"
          >
            <ArrowLeft size={18} aria-hidden="true" />
            {T("settingsBack")}
          </Link>
          <span
            className="inline-flex items-center gap-2 text-sm font-semibold"
            aria-live="polite"
          >
            {unlocked ? (
              <>
                <Unlock size={18} aria-hidden="true" className="text-primary" />
                {T("settingsUnlocked")}
              </>
            ) : (
              <>
                <Lock size={18} aria-hidden="true" />
                {T("settingsLocked")}
              </>
            )}
          </span>
        </div>
      </header>

      <main className="container max-w-3xl py-8">
        <h1 className="text-3xl font-bold text-primary mb-2">{T("settingsTitle")}</h1>
        <p className="text-sm text-muted-foreground mb-6">{T("settingsLocalNotice")}</p>

        {!unlocked && needsSetup && (
          <PinSetup
            T={T}
            onDone={() => {
              setNeedsSetup(false);
              setUnlocked(true);
            }}
          />
        )}
        {!unlocked && !needsSetup && (
          <PinUnlock
            T={T}
            onUnlock={() => setUnlocked(true)}
            onReset={() => {
              resetAll();
              setNeedsSetup(true);
            }}
          />
        )}
        {unlocked && (
          <GloveSettingsForm
            T={T}
            onLock={() => setUnlocked(false)}
            onResetAll={() => {
              resetAll();
              setUnlocked(false);
              setNeedsSetup(true);
            }}
          />
        )}
      </main>
    </div>
  );
};

/* ---------- PIN Setup ---------- */
const PinSetup = ({ T, onDone }: { T: (k: string) => string; onDone: () => void }) => {
  const [pin1, setPin1] = useState("");
  const [pin2, setPin2] = useState("");
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!/^\d{4,6}$/.test(pin1)) {
      setError(T("pinErrorLength"));
      return;
    }
    if (pin1 !== pin2) {
      setError(T("pinErrorMatch"));
      return;
    }
    await setPin(pin1);
    onDone();
  };

  return (
    <form
      onSubmit={submit}
      className="rounded-lg border-2 border-border bg-card p-6 space-y-4 max-w-md"
    >
      <h2 className="text-xl font-semibold">{T("pinSetupTitle")}</h2>
      <p className="text-sm text-muted-foreground">{T("pinSetupIntro")}</p>

      <div className="space-y-1">
        <label htmlFor="pin1" className="block text-sm font-medium">
          {T("pinNew")}
        </label>
        <input
          id="pin1"
          type="password"
          inputMode="numeric"
          pattern="[0-9]*"
          autoComplete="new-password"
          maxLength={6}
          value={pin1}
          onChange={(e) => setPin1(e.target.value.replace(/\D/g, ""))}
          className="w-full rounded-md border-2 border-border bg-background px-3 py-2 text-foreground focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-ring tracking-widest text-lg"
        />
      </div>
      <div className="space-y-1">
        <label htmlFor="pin2" className="block text-sm font-medium">
          {T("pinConfirm")}
        </label>
        <input
          id="pin2"
          type="password"
          inputMode="numeric"
          pattern="[0-9]*"
          autoComplete="new-password"
          maxLength={6}
          value={pin2}
          onChange={(e) => setPin2(e.target.value.replace(/\D/g, ""))}
          className="w-full rounded-md border-2 border-border bg-background px-3 py-2 text-foreground focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-ring tracking-widest text-lg"
        />
      </div>

      {error && (
        <p role="alert" className="text-sm font-medium text-destructive">
          {error}
        </p>
      )}

      <button
        type="submit"
        className="w-full rounded-md bg-primary text-primary-foreground font-semibold py-2.5 hover:opacity-90 focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-ring focus-visible:ring-offset-2"
      >
        {T("pinSave")}
      </button>
    </form>
  );
};

/* ---------- PIN Unlock ---------- */
const PinUnlock = ({
  T,
  onUnlock,
  onReset,
}: {
  T: (k: string) => string;
  onUnlock: () => void;
  onReset: () => void;
}) => {
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [showForgot, setShowForgot] = useState(false);
  const [lockMs, setLockMs] = useState(getLockoutRemainingMs());

  useEffect(() => {
    if (lockMs <= 0) return;
    const id = setInterval(() => {
      const r = getLockoutRemainingMs();
      setLockMs(r);
      if (r <= 0) clearInterval(id);
    }, 500);
    return () => clearInterval(id);
  }, [lockMs]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (lockMs > 0) return;
    const ok = await verifyPin(pin);
    if (ok) {
      onUnlock();
    } else {
      const r = getLockoutRemainingMs();
      setLockMs(r);
      setError(r > 0 ? T("pinLockout") : T("pinErrorWrong"));
      setPin("");
    }
  };

  return (
    <form
      onSubmit={submit}
      className="rounded-lg border-2 border-border bg-card p-6 space-y-4 max-w-md"
    >
      <h2 className="text-xl font-semibold">{T("pinUnlockTitle")}</h2>
      <p className="text-sm text-muted-foreground">{T("pinUnlockIntro")}</p>

      <div className="space-y-1">
        <label htmlFor="pin" className="block text-sm font-medium">
          {T("pinLabel")}
        </label>
        <input
          id="pin"
          type="password"
          inputMode="numeric"
          pattern="[0-9]*"
          autoComplete="off"
          maxLength={6}
          value={pin}
          onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
          autoFocus
          className="w-full rounded-md border-2 border-border bg-background px-3 py-2 text-foreground focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-ring tracking-widest text-lg"
        />
      </div>

      {error && (
        <p role="alert" className="text-sm font-medium text-destructive">
          {error}
          {lockMs > 0 ? ` (${Math.ceil(lockMs / 1000)}s)` : ""}
        </p>
      )}

      <button
        type="submit"
        disabled={lockMs > 0 || pin.length < 4}
        className="w-full rounded-md bg-primary text-primary-foreground font-semibold py-2.5 hover:opacity-90 focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {T("pinUnlock")}
      </button>

      <button
        type="button"
        onClick={() => setShowForgot((s) => !s)}
        className="text-sm text-primary underline underline-offset-4"
      >
        {T("pinForgot")}
      </button>
      {showForgot && (
        <div className="rounded-md border-2 border-border bg-muted p-3 space-y-2">
          <p className="text-sm">{T("pinForgotInfo")}</p>
          <button
            type="button"
            onClick={() => {
              if (window.confirm(T("resetConfirm"))) onReset();
            }}
            className="rounded-md bg-destructive text-destructive-foreground font-semibold px-3 py-2 text-sm hover:opacity-90"
          >
            {T("resetAll")}
          </button>
        </div>
      )}
    </form>
  );
};

/* ---------- Settings Form ---------- */
const GloveSettingsForm = ({
  T,
  onLock,
  onResetAll,
}: {
  T: (k: string) => string;
  onLock: () => void;
  onResetAll: () => void;
}) => {
  const [settings, setSettings] = useState<GloveSettings>(() => getSettings());
  const profiles = useMemo(() => getProfiles(), []);
  const [savedFlash, setSavedFlash] = useState(false);
  const [showChangePin, setShowChangePin] = useState(false);

  const profileLabel = useMemo(
    () => ({
      default: T("gsProfileDefault"),
      indoor: T("gsProfileIndoor"),
      outdoor: T("gsProfileOutdoor"),
      crowded: T("gsProfileCrowded"),
    }),
    [T],
  );

  const update = (patch: Partial<GloveSettings>) => {
    const next = { ...settings, ...patch };
    setSettings(next);
    saveSettings(next);
    setSavedFlash(true);
    window.setTimeout(() => setSavedFlash(false), 1500);
  };

  const switchProfile = (name: string) => {
    const p = profiles.find((p) => p.name === name);
    if (!p) return;
    const next = { ...p.settings, activeProfile: name };
    setSettings(next);
    saveSettings(next);
    setSavedFlash(true);
    window.setTimeout(() => setSavedFlash(false), 1500);
  };

  return (
    <div className="space-y-6">
      <div role="status" aria-live="polite" className="sr-only">
        {savedFlash ? T("gsSavedHint") : ""}
      </div>

      {/* Profile */}
      <section className="rounded-lg border-2 border-border bg-card p-6 space-y-3">
        <label htmlFor="profile" className="block text-base font-semibold">
          {T("gsProfile")}
        </label>
        <select
          id="profile"
          value={settings.activeProfile}
          onChange={(e) => switchProfile(e.target.value)}
          className="w-full rounded-md border-2 border-border bg-background px-3 py-2 text-foreground focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-ring"
        >
          {profiles.map((p) => (
            <option key={p.name} value={p.name}>
              {profileLabel[p.name as keyof typeof profileLabel] ?? p.name}
            </option>
          ))}
        </select>
      </section>

      {/* Vibration */}
      <section className="rounded-lg border-2 border-border bg-card p-6 space-y-4">
        <div className="flex items-baseline justify-between">
          <label htmlFor="vib" className="block text-base font-semibold">
            {T("gsVibration")}
          </label>
          <span className="text-sm font-mono" aria-live="polite">
            {settings.vibrationIntensity}%
          </span>
        </div>
        <Slider
          id="vib"
          min={0}
          max={100}
          step={5}
          value={[settings.vibrationIntensity]}
          onValueChange={(v) => update({ vibrationIntensity: v[0] })}
          aria-label={T("gsVibration")}
          aria-valuetext={`${settings.vibrationIntensity} %`}
        />
      </section>

      {/* Range */}
      <section className="rounded-lg border-2 border-border bg-card p-6 space-y-4">
        <div className="flex items-baseline justify-between">
          <label htmlFor="range" className="block text-base font-semibold">
            {T("gsRange")}
          </label>
          <span className="text-sm font-mono" aria-live="polite">
            {settings.detectionRangeM.toFixed(1)} m
          </span>
        </div>
        <Slider
          id="range"
          min={0.3}
          max={5}
          step={0.1}
          value={[settings.detectionRangeM]}
          onValueChange={(v) => update({ detectionRangeM: Math.round(v[0] * 10) / 10 })}
          aria-label={T("gsRange")}
          aria-valuetext={`${settings.detectionRangeM.toFixed(1)} Meter`}
        />
      </section>

      {/* Curve */}
      <section className="rounded-lg border-2 border-border bg-card p-6 space-y-3">
        <fieldset>
          <legend className="text-base font-semibold mb-3">{T("gsCurve")}</legend>
          <div className="flex flex-col gap-2">
            {(["linear", "soft", "aggressive"] as const).map((c) => (
              <label key={c} className="inline-flex items-center gap-3 cursor-pointer">
                <input
                  type="radio"
                  name="curve"
                  value={c}
                  checked={settings.sensitivityCurve === c}
                  onChange={() => update({ sensitivityCurve: c })}
                  className="h-5 w-5 accent-primary"
                />
                <span>
                  {c === "linear" && T("gsCurveLinear")}
                  {c === "soft" && T("gsCurveSoft")}
                  {c === "aggressive" && T("gsCurveAggressive")}
                </span>
              </label>
            ))}
          </div>
        </fieldset>
      </section>

      {/* Actions */}
      <section className="flex flex-wrap gap-3">
        <button
          type="button"
          onClick={onLock}
          className="inline-flex items-center gap-2 rounded-md border-2 border-border bg-card px-4 py-2 font-semibold hover:bg-muted focus-visible:outline-3 focus-visible:outline-offset-2"
        >
          <Lock size={18} aria-hidden="true" />
          {T("settingsLock")}
        </button>
        <button
          type="button"
          onClick={() => setShowChangePin((s) => !s)}
          className="rounded-md border-2 border-border bg-card px-4 py-2 font-semibold hover:bg-muted focus-visible:outline-3 focus-visible:outline-offset-2"
        >
          {T("gsChangePin")}
        </button>
        <button
          type="button"
          onClick={() => {
            if (window.confirm(T("resetConfirm"))) {
              onResetAll();
            }
          }}
          className="rounded-md bg-destructive text-destructive-foreground px-4 py-2 font-semibold hover:opacity-90 focus-visible:outline-3 focus-visible:outline-offset-2"
        >
          {T("resetAll")}
        </button>
      </section>

      {showChangePin && <ChangePinForm T={T} onDone={() => setShowChangePin(false)} />}
    </div>
  );
};

/* ---------- Change PIN ---------- */
const ChangePinForm = ({ T, onDone }: { T: (k: string) => string; onDone: () => void }) => {
  const [current, setCurrent] = useState("");
  const [next1, setNext1] = useState("");
  const [next2, setNext2] = useState("");
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    const ok = await verifyPin(current);
    if (!ok) {
      setError(T("pinErrorWrong"));
      return;
    }
    if (!/^\d{4,6}$/.test(next1)) {
      setError(T("pinErrorLength"));
      return;
    }
    if (next1 !== next2) {
      setError(T("pinErrorMatch"));
      return;
    }
    await setPin(next1);
    onDone();
  };

  return (
    <form
      onSubmit={submit}
      className="rounded-lg border-2 border-border bg-card p-6 space-y-4 max-w-md"
    >
      <h2 className="text-lg font-semibold">{T("gsChangePin")}</h2>
      {[
        { id: "cur", label: T("pinCurrent"), val: current, set: setCurrent },
        { id: "n1", label: T("pinNew"), val: next1, set: setNext1 },
        { id: "n2", label: T("pinConfirm"), val: next2, set: setNext2 },
      ].map((f) => (
        <div key={f.id} className="space-y-1">
          <label htmlFor={f.id} className="block text-sm font-medium">
            {f.label}
          </label>
          <input
            id={f.id}
            type="password"
            inputMode="numeric"
            pattern="[0-9]*"
            maxLength={6}
            value={f.val}
            onChange={(e) => f.set(e.target.value.replace(/\D/g, ""))}
            className="w-full rounded-md border-2 border-border bg-background px-3 py-2 text-foreground focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-ring tracking-widest text-lg"
          />
        </div>
      ))}
      {error && (
        <p role="alert" className="text-sm font-medium text-destructive">
          {error}
        </p>
      )}
      <button
        type="submit"
        className="w-full rounded-md bg-primary text-primary-foreground font-semibold py-2.5 hover:opacity-90 focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-ring focus-visible:ring-offset-2"
      >
        {T("pinSave")}
      </button>
    </form>
  );
};

export default Settings;