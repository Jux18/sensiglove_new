-- Run this once in the Supabase SQL Editor (https://supabase.com/dashboard → SQL Editor)

create table if not exists glove_settings (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid references auth.users(id) on delete cascade not null unique,
  settings    jsonb not null default '{}',
  profiles    jsonb not null default '[]',
  updated_at  timestamptz default now()
);

-- Row Level Security: every user can only read/write their own row
alter table glove_settings enable row level security;

create policy "Own settings only"
  on glove_settings
  for all
  using (auth.uid() = user_id);
