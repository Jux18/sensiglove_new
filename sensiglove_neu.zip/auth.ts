import { supabase } from "./supabase";

/** Sign up with email + password. Supabase sends a confirmation email. */
export async function registerUser(email: string, password: string): Promise<void> {
  const { error } = await supabase.auth.signUp({ email, password });
  if (error) {
    if (error.message.toLowerCase().includes("already registered")) {
      throw new Error("USER_EXISTS");
    }
    throw new Error(error.message);
  }
}

/** Sign in with email + password. */
export async function loginUser(email: string, password: string): Promise<void> {
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) {
    if (
      error.message.toLowerCase().includes("invalid login") ||
      error.message.toLowerCase().includes("invalid credentials")
    ) {
      throw new Error("WRONG_PASSWORD");
    }
    throw new Error(error.message);
  }
}

/** Sign out. */
export async function logoutUser(): Promise<void> {
  await supabase.auth.signOut();
}

/**
 * Returns the email of the currently signed-in user, or null.
 * This is synchronous based on the cached session — safe to call on mount.
 */
export function getCurrentUser(): string | null {
  // getSession is async, but Supabase caches the session in localStorage.
  // We access the internal store synchronously for the initial render.
  const raw = localStorage.getItem(
    `sb-${new URL(import.meta.env.VITE_SUPABASE_URL).hostname.split(".")[0]}-auth-token`
  );
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    return parsed?.user?.email ?? null;
  } catch {
    return null;
  }
}

/**
 * Send a password-reset email. Replaces the old "reset all accounts" nuclear option.
 */
export async function sendPasswordReset(email: string): Promise<void> {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: window.location.origin,
  });
  if (error) throw new Error(error.message);
}

/**
 * Subscribe to auth state changes (login / logout / token refresh).
 * Returns the unsubscribe function.
 */
export function onAuthChange(
  callback: (email: string | null) => void
): () => void {
  const {
    data: { subscription },
  } = supabase.auth.onAuthStateChange((_event, session) => {
    callback(session?.user?.email ?? null);
  });
  return () => subscription.unsubscribe();
}
