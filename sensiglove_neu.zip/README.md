# SensiGlove × Supabase — Integration Guide

## Neue Dateien
| Datei | Beschreibung |
|---|---|
| `src/lib/supabase.ts` | Supabase Client (einmalig instanziiert) |
| `src/lib/auth.ts` | Ersetzt `localAuth.ts` komplett |
| `src/lib/gloveStorage.ts` | Cloud-sync für Settings + Profile |
| `src/components/AuthDialog.tsx` | Echte Auth (Login, Register, Password-Reset per Email) |
| `.env.example` | Vorlage für die Umgebungsvariablen |
| `supabase-setup.sql` | Einmalig im Supabase SQL Editor ausführen |

---

## Schritt 1 — Supabase-Paket installieren

```bash
npm install @supabase/supabase-js
```

## Schritt 2 — .env anlegen

```bash
cp .env.example .env
```

Dann in `.env` eintragen:
- `VITE_SUPABASE_URL` → `https://dupzzgkjtvqgbawmkhrk.supabase.co`
- `VITE_SUPABASE_ANON_KEY` → deinen **anon public** Key aus Supabase → Settings → API

## Schritt 3 — Datenbank-Tabelle erstellen

Im Supabase Dashboard → **SQL Editor** → Inhalt von `supabase-setup.sql` einfügen → Run.

## Schritt 4 — Dateien ersetzen

Folgende Dateien aus diesem Ordner ins Projekt kopieren und die alten überschreiben:

```
src/lib/supabase.ts          ← neu
src/lib/auth.ts              ← neu (ersetzt localAuth.ts)
src/lib/gloveStorage.ts      ← ersetzt alte Version
src/components/AuthDialog.tsx ← ersetzt alte Version
```

> `localAuth.ts` kann danach gelöscht werden.

## Schritt 5 — Index.tsx anpassen (3 kleine Änderungen)

Lies `src/pages/Index.patch.txt` — dort stehen die drei Stellen die geändert werden müssen.

Kurzfassung:
1. Import von `localAuth` → `auth` umbiegen
2. `onAuthChange`-Listener in einem `useEffect` ergänzen
3. Logout-Handler auf `async/await` umstellen

## Schritt 6 — Email-Bestätigung in Supabase konfigurieren (optional)

Supabase versendet nach der Registrierung automatisch eine Bestätigungsmail.
Für Entwicklung/Demo kann man das abschalten:
**Supabase → Authentication → Providers → Email → "Confirm email" deaktivieren**

---

## Was sich gegenüber vorher ändert

| Vorher (localStorage) | Nachher (Supabase) |
|---|---|
| Accounts nur im Browser gespeichert | Accounts in Supabase Auth |
| Passwort vergessen = alle Accounts löschen | Echtes Password-Reset per Email |
| Settings nur lokal | Settings cloud-synced pro User |
| Kein echtes Login | JWT-Session, automatisch refreshed |

## Guest Mode

Nicht eingeloggte Nutzer können die Seite weiterhin nutzen.
Settings werden dann wie bisher in localStorage gespeichert.
